<?php
$con= mysqli_connect("localhost","root","","library","3306");

?>